using System;
using System.Reflection;
using System.Text.RegularExpressions;
using Microsoft.BizTalk.BaseFunctoids;

namespace RegExFunctoids
{
	/// <summary>
	/// Summary description for RegExMatchFunctoid.
	/// </summary>
	public class RegExMatchFunctoid : BaseFunctoid
	{
		public RegExMatchFunctoid() : base()
		{
			this.ID = 6100;
			SetupResourceAssembly("RegExFunctoids.Resource", Assembly.GetExecutingAssembly());

			SetName("REGEXMATCH_NAME");
			SetTooltip("REGEXMATCH_TOOLTIP");
			SetDescription("REGEXMATCH_DESCRIPTION");
			SetBitmap("REGEXMATCH_BITMAP");

			this.SetMinParams(2);
			this.SetMaxParams(2);

			SetExternalFunctionName(GetType().Assembly.FullName, "RegExFunctoids.RegExMatchFunctoid", "RegExMatch");

			this.Category = FunctoidCategory.String;

			this.OutputConnectionType = ConnectionType.AllExceptRecord;

			// Parameter 1
			AddInputConnectionType(ConnectionType.AllExceptRecord);

			// Parameter 2
			AddInputConnectionType(ConnectionType.AllExceptRecord);

		}

		public string RegExMatch(string val1, string val2)
		{
			try
			{
				Regex regex = new Regex(val2);

				MatchCollection matches = regex.Matches(val1);

				if (matches.Count > 0)
				{
					return matches[0].ToString();
				}
				else
				{
					return String.Empty;
				}
			}
			catch
			{
				return String.Empty;
			}

		}
	}
}
